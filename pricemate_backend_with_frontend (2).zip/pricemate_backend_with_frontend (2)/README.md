
# PriceMate - Backend (Python / Flask)

## What this contains
- `app.py` - Flask API with endpoints:
  - `GET /health` - checks DB connectivity.
  - `GET /api/products` - lists product ids and names.
  - `GET /api/price/<product>` - returns price history rows for products matching `<product>` (partial, case-insensitive).

- `requirements.txt` - Python dependencies.
- `.env.example` - example environment file.
- `price_recommendation.sql` - your MySQL dump (included).

## Setup (local)
1. Install dependencies (preferably in a virtualenv):
   ```bash
   pip install -r requirements.txt
   ```

2. Create the database and import the SQL (you can use MySQL CLI or Workbench):
   ```sql
   CREATE DATABASE price_recommendation;
   USE price_recommendation;
   SOURCE price_recommendation.sql;
   ```

   Or from shell (adjust path and user):
   ```bash
   mysql -u root -p price_recommendation < price_recommendation.sql
   ```

3. Copy `.env.example` -> `.env` and set your DB credentials.
   ```bash
   cp .env.example .env
   # edit .env to add your DB_PASSWORD etc.
   ```

4. Run the Flask app:
   ```bash
   python app.py
   ```

5. Example requests:
   - List products: `GET http://localhost:5000/api/products`
   - Get price history: `GET http://localhost:5000/api/price/iPhone`

## Notes
- The Flask app uses `pymysql` and reads DB credentials from environment variables.
- This backend is minimal and intended to connect to your `price_recommendation` MySQL dump shipped in this zip.
