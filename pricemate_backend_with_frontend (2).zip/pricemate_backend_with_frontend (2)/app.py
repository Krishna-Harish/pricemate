import os
from flask import Flask, request, render_template, jsonify
from flask_cors import CORS
import pymysql
from dotenv import load_dotenv

# Load environment variables from .env
load_dotenv()

# Load DB config from environment
DB_HOST = os.getenv('DB_HOST', 'localhost')
DB_PORT = int(os.getenv('DB_PORT', 3306))
DB_USER = os.getenv('DB_USER', 'root')
DB_PASSWORD = os.getenv('DB_PASSWORD', '')
DB_NAME = os.getenv('DB_NAME', 'price_recommendation')

app = Flask(__name__)
CORS(app)  # Enable Cross-Origin Resource Sharing (for frontend APIs)

# -------------------- DB CONNECTION --------------------
def get_db_connection():
    """Establish a database connection."""
    return pymysql.connect(
        host=DB_HOST,
        port=DB_PORT,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME,
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=True
    )

# -------------------- ROUTES --------------------
@app.route('/')
def home():
    """Render the main HTML page."""
    return render_template('pro8.html')  # Make sure 'templates/pro8.html' exists

@app.route('/health')
def health():
    """Check server and DB connection."""
    conn = None
    try:
        conn = get_db_connection()
        # Smart content negotiation
        if request.accept_mimetypes.accept_json and not request.accept_mimetypes.accept_html:
            return jsonify({'status': 'ok', 'db': 'connected'})
        return "<h3>✅ Server is running and database connection successful!</h3>", 200
    except Exception as e:
        if request.accept_mimetypes.accept_json:
            return jsonify({'status': 'error', 'detail': str(e)}), 500
        return f"<h3>❌ Error: {str(e)}</h3>", 500
    finally:
        if conn:
            conn.close()

@app.route('/api/price/<product>')
def get_price(product):
    """
    Return all price records for a given product (partial name match).
    """
    q = "%" + product + "%"
    sql = """
        SELECT p.name AS product_name, ph.site, ph.price, ph.date
        FROM price_history ph
        JOIN products p ON ph.product_id = p.id
        WHERE LOWER(p.name) LIKE LOWER(%s)
        ORDER BY ph.date ASC;
    """
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cur:
            cur.execute(sql, (q,))
            rows = cur.fetchall()
        return jsonify(rows)
    except Exception as e:
        return jsonify({'error': 'database error', 'detail': str(e)}), 500
    finally:
        if conn:
            conn.close()

@app.route('/api/products')
def list_products():
    """
    List all products in the database.
    """
    sql = "SELECT id, name FROM products ORDER BY name;"
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cur:
            cur.execute(sql)
            rows = cur.fetchall()
        return jsonify(rows)
    except Exception as e:
        return jsonify({'error': 'database error', 'detail': str(e)}), 500
    finally:
        if conn:
            conn.close()

# -------------------- APP ENTRY POINT --------------------
if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)
