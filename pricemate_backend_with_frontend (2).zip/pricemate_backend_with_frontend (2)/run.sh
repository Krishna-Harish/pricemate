
#!/bin/bash
# simple helper to create virtualenv, install and run
python3 -m venv venv
. venv/bin/activate
pip install -r requirements.txt
echo "Copy .env.example to .env and adjust credentials, then run: python app.py"
